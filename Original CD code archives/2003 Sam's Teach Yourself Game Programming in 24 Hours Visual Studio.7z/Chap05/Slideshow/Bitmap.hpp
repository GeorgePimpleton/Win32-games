//-----------------------------------------------------------------
// Bitmap Object
// C++ Header - Bitmap.hpp
//-----------------------------------------------------------------

#pragma once

//-----------------------------------------------------------------
// include files
//-----------------------------------------------------------------
#include <windows.h>

//-----------------------------------------------------------------
// custom data types
//-----------------------------------------------------------------
struct BITMAPINFO_256
{
   BITMAPINFOHEADER bmiHeader;
   RGBQUAD          bmiColors[256];
};

//-----------------------------------------------------------------
// Bitmap class
//-----------------------------------------------------------------
class Bitmap
{
protected:
   // member variables
   HBITMAP m_hBitmap;
   int     m_iWidth, m_iHeight;

   // helper methods
   void Free();

public:
   // constructor(s)/destructor
            Bitmap();
            Bitmap(HDC hDC, LPCTSTR szFileName);
            Bitmap(HDC hDC, UINT uiResID, HINSTANCE hInstance);
            Bitmap(HDC hDC, int iWidth, int iHeight, COLORREF crColor = RGB(0, 0, 0));
   virtual ~Bitmap();

   // general methods
   BOOL Create(HDC hDC, LPCTSTR szFileName);
   BOOL Create(HDC hDC, UINT uiResID, HINSTANCE hInstance);
   BOOL Create(HDC hDC, int iWidth, int iHeight, COLORREF crColor);
   void Draw(HDC hDC, int x, int y);

   int  GetWidth()  { return m_iWidth; };
   int  GetHeight() { return m_iHeight; };
};
