//-----------------------------------------------------------------
// Bitmap Object
// C++ Source - Bitmap.cpp
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// include files
//-----------------------------------------------------------------
#include "Bitmap.hpp"

//-----------------------------------------------------------------
// Bitmap constructor(s)/destructor
//-----------------------------------------------------------------
Bitmap::Bitmap()
   : m_hBitmap(NULL), m_iWidth(0), m_iHeight(0)
{ }


// create a bitmap from a file
Bitmap::Bitmap(HDC hDC, LPCTSTR szFileName)
   : m_hBitmap(NULL), m_iWidth(0), m_iHeight(0)
{
   Create(hDC, szFileName);
}


// create a bitmap from a resource
Bitmap::Bitmap(HDC hDC, UINT uiResID, HINSTANCE hInstance)
   : m_hBitmap(NULL), m_iWidth(0), m_iHeight(0)
{
   Create(hDC, uiResID, hInstance);
}


// create a blank bitmap from scratch
Bitmap::Bitmap(HDC hDC, int iWidth, int iHeight, COLORREF crColor)
   : m_hBitmap(NULL), m_iWidth(0), m_iHeight(0)
{
   Create(hDC, iWidth, iHeight, crColor);
}


Bitmap::~Bitmap()
{
   Free();
}

//-----------------------------------------------------------------
// Bitmap helper methods
//-----------------------------------------------------------------
void Bitmap::Free()
{
   // delete the bitmap graphics object
   if (m_hBitmap != NULL)
   {
      DeleteObject(m_hBitmap);
      m_hBitmap = NULL;
   }
}


//-----------------------------------------------------------------
// Bitmap general methods
//-----------------------------------------------------------------
BOOL Bitmap::Create(HDC hDC, LPCTSTR szFileName)
{
   // free any previous bitmap info
   Free();

   // open the bitmap file
   HANDLE hFile = CreateFile(szFileName, GENERIC_READ, FILE_SHARE_READ, NULL,
                             OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

   if (hFile == INVALID_HANDLE_VALUE)
   {
      return FALSE;
   }

   // read the bitmap file header
   BITMAPFILEHEADER bmfHeader;
   DWORD            dwBytesRead;
   BOOL             bOK = ReadFile(hFile, &bmfHeader, sizeof(BITMAPFILEHEADER),
                                   &dwBytesRead, NULL);

   if ((!bOK) || (dwBytesRead != sizeof(BITMAPFILEHEADER)) || (bmfHeader.bfType != 0x4D42))
   {
      CloseHandle(hFile);
      return FALSE;
   }

   BITMAPINFO* pBitmapInfo = (BITMAPINFO*) (new BITMAPINFO_256);

   if (pBitmapInfo != NULL)
   {
      // read the bitmap info header
      bOK = ReadFile(hFile, pBitmapInfo, sizeof(BITMAPINFOHEADER), &dwBytesRead, NULL);

      if ((!bOK) || (dwBytesRead != sizeof(BITMAPINFOHEADER)))
      {
         CloseHandle(hFile);
         Free();

         return FALSE;
      }

      // store the width and height of the bitmap
      m_iWidth  = (int) pBitmapInfo->bmiHeader.biWidth;
      m_iHeight = (int) pBitmapInfo->bmiHeader.biHeight;

      // skip (forward or backward) to the color info, if necessary
      if (pBitmapInfo->bmiHeader.biSize != sizeof(BITMAPINFOHEADER))
      {
         SetFilePointer(hFile, pBitmapInfo->bmiHeader.biSize - sizeof(BITMAPINFOHEADER), NULL, FILE_CURRENT);
      }

      // read the color info
      bOK = ReadFile(hFile, pBitmapInfo->bmiColors, pBitmapInfo->bmiHeader.biClrUsed * sizeof(RGBQUAD),
                     &dwBytesRead, NULL);

      // get a handle to the bitmap and copy the image bits
      PBYTE pBitmapBits;

      m_hBitmap = CreateDIBSection(hDC, pBitmapInfo, DIB_RGB_COLORS, (PVOID*) &pBitmapBits, NULL, 0);

      if ((m_hBitmap != NULL) && (pBitmapBits != NULL))
      {
         SetFilePointer(hFile, bmfHeader.bfOffBits, NULL, FILE_BEGIN);

         bOK = ReadFile(hFile, pBitmapBits, pBitmapInfo->bmiHeader.biSizeImage, &dwBytesRead, NULL);

         if (bOK)
         {
            return TRUE;
         }
      }
   }

   // something went wrong, so cleanup everything
   Free();
   return FALSE;
}


BOOL Bitmap::Create(HDC hDC, UINT uiResID, HINSTANCE hInstance)
{
   // free any previous dib info
   Free();

   // find the bitmap resource
   HRSRC hResInfo = FindResource(hInstance, MAKEINTRESOURCE(uiResID), RT_BITMAP);

   if (hResInfo == NULL)
   {
      return FALSE;
   }

   // load the bitmap resource
   HGLOBAL hMemBitmap = LoadResource(hInstance, hResInfo);

   if (hMemBitmap == NULL)
   {
      return FALSE;
   }

   // lock the resource and access the entire bitmap image
   PBYTE pBitmapImage = (BYTE*) LockResource(hMemBitmap);

   if (pBitmapImage == NULL)
   {
      FreeResource(hMemBitmap);
      return FALSE;
   }

   // store the width and height of the bitmap
   BITMAPINFO* pBitmapInfo = (BITMAPINFO*) pBitmapImage;

   m_iWidth  = (int) pBitmapInfo->bmiHeader.biWidth;
   m_iHeight = (int) pBitmapInfo->bmiHeader.biHeight;

   // get a handle to the bitmap and copy the image bits
   PBYTE pBitmapBits;

   m_hBitmap = CreateDIBSection(hDC, pBitmapInfo, DIB_RGB_COLORS, (PVOID*) &pBitmapBits, NULL, 0);

   if ((m_hBitmap != NULL) && (pBitmapBits != NULL))
   {
      const PBYTE pTempBits = pBitmapImage + pBitmapInfo->bmiHeader.biSize + pBitmapInfo->bmiHeader.biClrUsed * sizeof(RGBQUAD);
      CopyMemory(pBitmapBits, pTempBits, pBitmapInfo->bmiHeader.biSizeImage);

      // unlock and free the bitmap graphics object
      UnlockResource(hMemBitmap);
      FreeResource(hMemBitmap);

      return TRUE;
   }

   // something went wrong, so cleanup everything
   UnlockResource(hMemBitmap);
   FreeResource(hMemBitmap);
   Free();

   return FALSE;
}


BOOL Bitmap::Create(HDC hDC, int iWidth, int iHeight, COLORREF crColor)
{
   // create a blank bitmap
   m_hBitmap = CreateCompatibleBitmap(hDC, iWidth, iHeight);

   if (m_hBitmap == NULL)
   {
      return FALSE;
   }

   // set the width and height
   m_iWidth  = iWidth;
   m_iHeight = iHeight;

   // create a memory device context to draw on the bitmap
   HDC hMemDC = CreateCompatibleDC(hDC);

   // create a solid brush to fill the bitmap
   HBRUSH hBrush = CreateSolidBrush(crColor);

   // select the bitmap into the device context
   HBITMAP hOldBitmap = (HBITMAP) SelectObject(hMemDC, m_hBitmap);

   // fill the bitmap with a solid color
   RECT rcBitmap = { 0, 0, m_iWidth, m_iHeight };

   FillRect(hMemDC, &rcBitmap, hBrush);

   // cleanup
   SelectObject(hMemDC, hOldBitmap);
   DeleteDC(hMemDC);
   DeleteObject(hBrush);

   return TRUE;
}


void Bitmap::Draw(HDC hDC, int x, int y)
{
   if (m_hBitmap != NULL)
   {
      // create a memory device context for the bitmap
      HDC hMemDC = CreateCompatibleDC(hDC);

      // select the bitmap into the device context
      HBITMAP hOldBitmap = (HBITMAP) SelectObject(hMemDC, m_hBitmap);

      // draw the bitmap to the destination device context
      BitBlt(hDC, x, y, GetWidth(), GetHeight(), hMemDC, 0, 0, SRCCOPY);

      // restore and delete the memory device context
      SelectObject(hMemDC, hOldBitmap);
      DeleteDC(hMemDC);
   }
}