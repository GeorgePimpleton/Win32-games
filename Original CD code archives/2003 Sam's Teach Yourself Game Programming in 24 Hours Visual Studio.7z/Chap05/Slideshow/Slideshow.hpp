//-----------------------------------------------------------------
// Slideshow Application
// C++ Header - Slideshow.hpp
//-----------------------------------------------------------------

#pragma once

//-----------------------------------------------------------------
// include files
//-----------------------------------------------------------------
#include <windows.h>
#include "resource.h"
#include "GameEngine.hpp"
#include "Bitmap.hpp"

//-----------------------------------------------------------------
// global variables
//-----------------------------------------------------------------
HINSTANCE   _hInstance;
GameEngine* _pGame;
const int   _iNUMSLIDES = 7;
Bitmap*     _pSlides[_iNUMSLIDES];
int         _iCurSlide;
