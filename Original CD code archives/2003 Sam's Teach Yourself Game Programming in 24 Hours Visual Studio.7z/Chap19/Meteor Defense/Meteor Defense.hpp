//-----------------------------------------------------------------
// Meteor Defense Application
// C++ Header - MeteorDefense.hpp
//-----------------------------------------------------------------

#pragma once

//-----------------------------------------------------------------
// include files
//-----------------------------------------------------------------
#include <windows.h>
#include "random_toolkit.hpp"
#include "resource.h"
#include "GameEngine.hpp"
#include "Bitmap.hpp"
#include "Sprite.hpp"
#include "Background.hpp"

//-----------------------------------------------------------------
// global variables
//-----------------------------------------------------------------
GameEngine*       _pGame;
HDC               _hOffscreenDC;
HBITMAP           _hOffscreenBitmap;
Bitmap*           _pGroundBitmap;
Bitmap*           _pTargetBitmap;
Bitmap*           _pCityBitmap;
Bitmap*           _pMeteorBitmap;
Bitmap*           _pMissileBitmap;
Bitmap*           _pExplosionBitmap;
Bitmap*           _pGameOverBitmap;
StarryBackground* _pBackground;
int               _iNumCities;
int               _iScore;
int               _iDifficulty;
BOOL              _bGameOver;

//-----------------------------------------------------------------
// function declarations
//-----------------------------------------------------------------
void NewGame();
void AddMeteor();
