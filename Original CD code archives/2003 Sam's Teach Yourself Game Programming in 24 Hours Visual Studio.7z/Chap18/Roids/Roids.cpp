//-----------------------------------------------------------------
// Roids Application
// C++ Source - Roids.cpp
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// include files
//-----------------------------------------------------------------
#include "Roids.hpp"

//-----------------------------------------------------------------
// game engine functions
//-----------------------------------------------------------------
BOOL GameInitialize(HINSTANCE hInstance)
{
   // Create the game engine
   _pGame = new GameEngine(hInstance, TEXT("Roids"), TEXT("Roids"),
                           IDI_ROIDS, IDI_ROIDS_SM, 500, 400);

   if (_pGame == NULL)
   {
      return FALSE;
   }

   // set the frame rate
   _pGame->SetFrameRate(30);

   return TRUE;
}


void GameStart(HWND hWindow)
{
   // seed the random number generator
   rtk::srand();

   // create the offscreen device context and bitmap
   _hOffscreenDC     = CreateCompatibleDC(GetDC(hWindow));
   _hOffscreenBitmap = CreateCompatibleBitmap(GetDC(hWindow), _pGame->GetWidth(), _pGame->GetHeight());

   SelectObject(_hOffscreenDC, _hOffscreenBitmap);

   // create the starry background
   _pBackground = new StarryBackground(500, 400);

   // create and load the asteroid bitmap
   _pAsteroidBitmap = new Bitmap(IDB_ASTEROID, GetModuleHandle(NULL));

   // create the asteroid sprites
   RECT    rcBounds = { 0, 0, 500, 400 };
   Sprite* pSprite;

   pSprite = new Sprite(_pAsteroidBitmap, rcBounds, BA_WRAP);
   pSprite->SetNumFrames(14);
   pSprite->SetFrameDelay(1);
   pSprite->SetPosition(250, 200);
   pSprite->SetVelocity(-3, 1);
   _pGame->AddSprite(pSprite);

   pSprite = new Sprite(_pAsteroidBitmap, rcBounds, BA_WRAP);
   pSprite->SetNumFrames(14);
   pSprite->SetFrameDelay(2);
   pSprite->SetPosition(250, 200);
   pSprite->SetVelocity(3, -2);
   _pGame->AddSprite(pSprite);

   pSprite = new Sprite(_pAsteroidBitmap, rcBounds, BA_WRAP);
   pSprite->SetNumFrames(14);
   pSprite->SetFrameDelay(3);
   pSprite->SetPosition(250, 200);
   pSprite->SetVelocity(-2, -4);
   _pGame->AddSprite(pSprite);
}


void GameEnd()
{
   // cleanup the offscreen device context and bitmap
   DeleteObject(_hOffscreenBitmap);
   DeleteDC(_hOffscreenDC);

   // cleanup the asteroid bitmap
   delete _pAsteroidBitmap;

   // cleanup the background
   delete _pBackground;

   // cleanup the sprites
   _pGame->CleanupSprites();

   // cleanup the game engine
   delete _pGame;
}


void GameActivate(HWND hWindow)
{ }


void GameDeactivate(HWND hWindow)
{ }


void GamePaint(HDC hDC)
{
   // draw the background
   _pBackground->Draw(hDC);

   // draw the sprites
   _pGame->DrawSprites(hDC);
}


void GameCycle()
{
   // update the background
   _pBackground->Update();

   // update the sprites
   _pGame->UpdateSprites();

   // obtain a device context for repainting the game
   HWND hWindow = _pGame->GetWindow();
   HDC  hDC     = GetDC(hWindow);

   // paint the game to the offscreen device context
   GamePaint(_hOffscreenDC);

   // blit the offscreen bitmap to the game screen
   BitBlt(hDC, 0, 0, _pGame->GetWidth(), _pGame->GetHeight(), _hOffscreenDC, 0, 0, SRCCOPY);

   // cleanup
   ReleaseDC(hWindow, hDC);
}


void HandleKeys()
{ }


void MouseButtonDown(int x, int y, BOOL bLeft)
{ }


void MouseButtonUp(int x, int y, BOOL bLeft)
{ }


void MouseMove(int x, int y)
{ }


void HandleJoystick(JOYSTATE jsJoystickState)
{ }


BOOL SpriteCollision(Sprite* pSpriteHitter, Sprite* pSpriteHittee)
{
   return FALSE;
}