//-----------------------------------------------------------------
// Space Out 2 Application
// C++ Source - Space Out 2.cpp
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// include files
//-----------------------------------------------------------------
#include "Space Out 2.hpp"

//-----------------------------------------------------------------
// game engine functions
//-----------------------------------------------------------------
BOOL GameInitialize(HINSTANCE hInstance)
{
   // create the game engine
   _pGame = new GameEngine(hInstance, TEXT("Space Out 2"), TEXT("Space Out 2"),
                           IDI_SPACEOUT, IDI_SPACEOUT_SM, 600, 450);

   if (_pGame == NULL)
   {
      return FALSE;
   }

   // set the frame rate
   _pGame->SetFrameRate(30);

   return TRUE;
}


void GameStart(HWND hWindow)
{
   // seed the random number generator
   rtk::srand();

   // create the offscreen device context and bitmap
   _hOffscreenDC     = CreateCompatibleDC(GetDC(hWindow));
   _hOffscreenBitmap = CreateCompatibleBitmap(GetDC(hWindow), _pGame->GetWidth(), _pGame->GetHeight());

   SelectObject(_hOffscreenDC, _hOffscreenBitmap);

   // create and load the bitmaps
   HINSTANCE hInstance = GetModuleHandle(NULL);

   _pSplashBitmap      = new Bitmap(IDB_SPLASH, hInstance);
   _pDesertBitmap      = new Bitmap(IDB_DESERT, hInstance);
   _pCarBitmap         = new Bitmap(IDB_CAR, hInstance);
   _pSmCarBitmap       = new Bitmap(IDB_SMCAR, hInstance);
   _pMissileBitmap     = new Bitmap(IDB_MISSILE, hInstance);
   _pBlobboBitmap      = new Bitmap(IDB_BLOBBO, hInstance);
   _pBMissileBitmap    = new Bitmap(IDB_BMISSILE, hInstance);
   _pJellyBitmap       = new Bitmap(IDB_JELLY, hInstance);
   _pJMissileBitmap    = new Bitmap(IDB_JMISSILE, hInstance);
   _pTimmyBitmap       = new Bitmap(IDB_TIMMY, hInstance);
   _pTMissileBitmap    = new Bitmap(IDB_TMISSILE, hInstance);
   _pSmExplosionBitmap = new Bitmap(IDB_SMEXPLOSION, hInstance);
   _pLgExplosionBitmap = new Bitmap(IDB_LGEXPLOSION, hInstance);
   _pGameOverBitmap    = new Bitmap(IDB_GAMEOVER, hInstance);

   // create the starry background
   _pBackground = new StarryBackground(600, 450);

   // set the splash screen variable
   _bSplash   = TRUE;
   _bGameOver = TRUE;
}


void GameEnd()
{
   // close the MIDI player for the background music
   _pGame->CloseMIDIPlayer();

   // cleanup the offscreen device context and bitmap
   DeleteObject(_hOffscreenBitmap);
   DeleteDC(_hOffscreenDC);

   // cleanup the bitmaps
   delete _pSplashBitmap;
   delete _pDesertBitmap;
   delete _pCarBitmap;
   delete _pSmCarBitmap;
   delete _pMissileBitmap;
   delete _pBlobboBitmap;
   delete _pBMissileBitmap;
   delete _pJellyBitmap;
   delete _pJMissileBitmap;
   delete _pTimmyBitmap;
   delete _pTMissileBitmap;
   delete _pSmExplosionBitmap;
   delete _pLgExplosionBitmap;
   delete _pGameOverBitmap;

   // cleanup the background
   delete _pBackground;

   // cleanup the sprites
   _pGame->CleanupSprites();

   // cleanup the game engine
   delete _pGame;
}


void GameActivate(HWND hWindow)
{
   if (!_bSplash)
   {
      // resume the background music
      _pGame->PlayMIDISong(TEXT(""), FALSE);
   }
}


void GameDeactivate(HWND hWindow)
{
   if (!_bSplash)
   {
      // pause the background music
      _pGame->PauseMIDISong();
   }
}


void GamePaint(HDC hDC)
{
   // draw the background
   _pBackground->Draw(hDC);

   // draw the desert bitmap
   _pDesertBitmap->Draw(hDC, 0, 371);

   if (_bSplash)
   {
      // draw the splash screen image
      _pSplashBitmap->Draw(hDC, 142, 100, TRUE);
   }
   else
   {
      // draw the sprites
      _pGame->DrawSprites(hDC);

      // draw the score
      TCHAR szText[64];
      RECT  rect = { 460, 0, 510, 30 };

      wsprintf(szText, TEXT("%d"), _iScore);
      SetBkMode(hDC, TRANSPARENT);
      SetTextColor(hDC, RGB(255, 255, 255));
      DrawText(hDC, szText, -1, &rect, DT_SINGLELINE | DT_RIGHT | DT_VCENTER);

      // draw the number of remaining lives (cars)
      for (int i = 0; i < _iNumLives; i++)
      {
         _pSmCarBitmap->Draw(hDC, 520 + (_pSmCarBitmap->GetWidth() * i), 10, TRUE);
      }

      // draw the game over message, if necessary
      if (_bGameOver)
      {
         _pGameOverBitmap->Draw(hDC, 170, 100, TRUE);
      }
   }
}


void GameCycle()
{
   if (!_bGameOver)
   {
      // randomly add aliens
      if (rtk::rand(0, _iDifficulty) == 0)
      {
         AddAlien();
      }

      // update the background
      _pBackground->Update();

      // update the sprites
      _pGame->UpdateSprites();

      // obtain a device context for repainting the game
      HWND hWindow = _pGame->GetWindow();
      HDC  hDC     = GetDC(hWindow);

      // paint the game to the offscreen device context
      GamePaint(_hOffscreenDC);

      // blit the offscreen bitmap to the game screen
      BitBlt(hDC, 0, 0, _pGame->GetWidth(), _pGame->GetHeight(), _hOffscreenDC, 0, 0, SRCCOPY);

      // cleanup
      ReleaseDC(hWindow, hDC);
   }
}


void HandleKeys()
{
   if (!_bGameOver)
   {
      // move the car based upon left/right key presses
      POINT ptVelocity = _pCarSprite->GetVelocity();

      if (GetAsyncKeyState(VK_LEFT) < 0)
      {
         // move left
         ptVelocity.x = max(ptVelocity.x - 1, -4);
         _pCarSprite->SetVelocity(ptVelocity);
      }
      else if (GetAsyncKeyState(VK_RIGHT) < 0)
      {
         // move right
         ptVelocity.x = min(ptVelocity.x + 2, 6);
         _pCarSprite->SetVelocity(ptVelocity);
      }

      // fire missiles based upon spacebar presses
      if ((++_iFireInputDelay > 6) && GetAsyncKeyState(VK_SPACE) < 0)
      {
         // create a new missile sprite
         RECT    rcBounds = { 0, 0, 600, 450 };
         RECT    rcPos    = _pCarSprite->GetPosition();
         Sprite* pSprite  = new Sprite(_pMissileBitmap, rcBounds, BA_DIE);

         pSprite->SetPosition(rcPos.left + 15, 400);
         pSprite->SetVelocity(0, -7);
         _pGame->AddSprite(pSprite);

         // play the missile (fire) sound
         PlaySound((LPCTSTR) IDW_MISSILE, GetModuleHandle(NULL), SND_ASYNC | SND_RESOURCE | SND_NOSTOP);

         // reset the input delay
         _iFireInputDelay = 0;
      }
   }

   // start a new game based upon an enter (return) key press
   if (GetAsyncKeyState(VK_RETURN) < 0)
   {
      if (_bSplash)
      {
         // start a new game without the splash screen
         _bSplash = FALSE;

         NewGame();
      }
      else if (_bGameOver)
      {
         // start a new game
         NewGame();
      }
   }
}


void MouseButtonDown(int x, int y, BOOL bLeft)
{ }


void MouseButtonUp(int x, int y, BOOL bLeft)
{ }


void MouseMove(int x, int y)
{ }


void HandleJoystick(JOYSTATE jsJoystickState)
{ }


BOOL SpriteCollision(Sprite* pSpriteHitter, Sprite* pSpriteHittee)
{
   // see if a player missile and an alien have collided
   Bitmap* pHitter = pSpriteHitter->GetBitmap();
   Bitmap* pHittee = pSpriteHittee->GetBitmap();
   if ((pHitter == _pMissileBitmap && (pHittee == _pBlobboBitmap ||
                                       pHittee == _pJellyBitmap || pHittee == _pTimmyBitmap)) ||
                                       (pHittee == _pMissileBitmap && (pHitter == _pBlobboBitmap ||
                                                                       pHitter == _pJellyBitmap || pHitter == _pTimmyBitmap)))
   {
      // play the small explosion sound
      PlaySound((LPCTSTR) IDW_LGEXPLODE, GetModuleHandle(NULL), SND_ASYNC | SND_RESOURCE);

      // kill both sprites
      pSpriteHitter->Kill();
      pSpriteHittee->Kill();

      // create a large explosion sprite at the alien's position
      RECT rcBounds = { 0, 0, 600, 450 };
      RECT rcPos;

      if (pHitter == _pMissileBitmap)
      {
         rcPos = pSpriteHittee->GetPosition();
      }
      else
      {
         rcPos = pSpriteHitter->GetPosition();
      }

      Sprite* pSprite = new Sprite(_pLgExplosionBitmap, rcBounds);
      pSprite->SetNumFrames(8, TRUE);
      pSprite->SetPosition(rcPos.left, rcPos.top);
      _pGame->AddSprite(pSprite);

      // update the score
      _iScore      += 25;
      _iDifficulty = max(80 - (_iScore / 20), 20);
   }

   // see if an alien missile has collided with the car
   if ((pHitter == _pCarBitmap && (pHittee == _pBMissileBitmap ||
                                   pHittee == _pJMissileBitmap || pHittee == _pTMissileBitmap)) ||
                                   (pHittee == _pCarBitmap && (pHitter == _pBMissileBitmap ||
                                                               pHitter == _pJMissileBitmap || pHitter == _pTMissileBitmap)))
   {
      // play the large explosion sound
      PlaySound((LPCTSTR) IDW_LGEXPLODE, GetModuleHandle(NULL), SND_ASYNC | SND_RESOURCE);

      // kill the missile sprite
      if (pHitter == _pCarBitmap)
      {
         pSpriteHittee->Kill();
      }
      else
      {
         pSpriteHitter->Kill();
      }

      // create a large explosion sprite at the car's position
      RECT rcBounds = { 0, 0, 600, 480 };
      RECT rcPos;

      if (pHitter == _pCarBitmap)
      {
         rcPos = pSpriteHitter->GetPosition();
      }
      else
      {
         rcPos = pSpriteHittee->GetPosition();
      }

      Sprite* pSprite = new Sprite(_pLgExplosionBitmap, rcBounds);
      pSprite->SetNumFrames(8, TRUE);
      pSprite->SetPosition(rcPos.left, rcPos.top);
      _pGame->AddSprite(pSprite);

      // move the car back to the start
      _pCarSprite->SetPosition(300, 405);

      // see if the game is over
      if (--_iNumLives == 0)
      {
         // play the game over sound
         PlaySound((LPCTSTR) IDW_GAMEOVER, GetModuleHandle(NULL), SND_ASYNC | SND_RESOURCE);

         _bGameOver = TRUE;
      }
   }

   return FALSE;
}


void SpriteDying(Sprite* pSprite)
{
   // see if an alien missile sprite is dying
   if (pSprite->GetBitmap() == _pBMissileBitmap ||
       pSprite->GetBitmap() == _pJMissileBitmap ||
       pSprite->GetBitmap() == _pTMissileBitmap)
   {
      // play the small explosion sound
      PlaySound((LPCTSTR) IDW_SMEXPLODE, GetModuleHandle(NULL), SND_ASYNC | SND_RESOURCE | SND_NOSTOP);

      // create a small explosion sprite at the missile's position
      RECT rcBounds = { 0, 0, 600, 450 };
      RECT rcPos    = pSprite->GetPosition();

      Sprite* pSprite = new Sprite(_pSmExplosionBitmap, rcBounds);
      pSprite->SetNumFrames(8, TRUE);
      pSprite->SetPosition(rcPos.left, rcPos.top);
      _pGame->AddSprite(pSprite);
   }
}


//-----------------------------------------------------------------
// functions
//-----------------------------------------------------------------
void NewGame()
{
   // clear the sprites
   _pGame->CleanupSprites();

   // initialize the game variables
   _iFireInputDelay = 0;
   _iScore          = 0;
   _iNumLives       = 3;
   _iDifficulty     = 80;
   _bGameOver       = FALSE;

   // create the car sprite
   RECT rcBounds = { 0, 0, 600, 450 };

   _pCarSprite = new Sprite(_pCarBitmap, rcBounds, BA_WRAP);
   _pCarSprite->SetPosition(300, 405);
   _pGame->AddSprite(_pCarSprite);

   // play the background music
   _pGame->PlayMIDISong(TEXT("Music.mid"));
}


void AddAlien()
{
   // create a new random alien sprite
   RECT         rcBounds = { 0, 0, 600, 410 };
   AlienSprite* pSprite  = nullptr;

   switch (rtk::rand(0, 2))
   {
   case 0:
      // Blobbo
      pSprite = new AlienSprite(_pBlobboBitmap, rcBounds, BA_BOUNCE);
      pSprite->SetNumFrames(8);
      pSprite->SetPosition((rtk::rand(0, 1) == 0) ? 0 : 600, rtk::rand(0, 370));
      pSprite->SetVelocity(rtk::rand(-2, 4), rtk::rand(-2, 4));
      break;

   case 1:
      // Jelly
      pSprite = new AlienSprite(_pJellyBitmap, rcBounds, BA_BOUNCE);
      pSprite->SetNumFrames(8);
      pSprite->SetPosition(rtk::rand(0, 600), rtk::rand(0, 370));
      pSprite->SetVelocity(rtk::rand(-2, 2), rtk::rand(3, 7));
      break;

   case 2:
      // Timmy
      pSprite = new AlienSprite(_pTimmyBitmap, rcBounds, BA_WRAP);
      pSprite->SetNumFrames(8);
      pSprite->SetPosition(rtk::rand(0, 600), rtk::rand(0, 370));
      pSprite->SetVelocity(rtk::rand(3, 9), 0);
      break;
   }

   // add the alien sprite
   _pGame->AddSprite(pSprite);
}