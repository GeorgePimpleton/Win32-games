//-----------------------------------------------------------------
// Game Skeleton Application
// C++ Source - Game Skeleton.cpp
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// include files
//-----------------------------------------------------------------
#include "Game Skeleton.hpp"

//-----------------------------------------------------------------
// game engine functions
//-----------------------------------------------------------------
BOOL GameInitialize(HINSTANCE hInstance)
{
   // create the game engine
   _pGame = new GameEngine(hInstance, TEXT("Game Skeleton"), TEXT("Game Skeleton"),
                           IDI_SKELETON, IDI_SKELETON_SM);

   if (_pGame == NULL)
   {
      return FALSE;
   }

   // set the frame rate
   _pGame->SetFrameRate(15);

   return TRUE;
}


void GameStart(HWND hWindow)
{
   // seed the random number generator
   rtk::srand();
}


void GameEnd()
{
   // cleanup the game engine
   delete _pGame;
}


void GameActivate(HWND hWindow)
{
   RECT rect;

   // draw activation text on the game screen
   GetClientRect(hWindow, &rect);

   HDC hDC = GetDC(hWindow);

   DrawText(hDC, TEXT("Activated!"), -1, &rect, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
   ReleaseDC(hWindow, hDC);
}


void GameDeactivate(HWND hWindow)
{
   RECT rect;

   // draw deactivation text on the game screen
   GetClientRect(hWindow, &rect);

   HDC hDC = GetDC(hWindow);

   DrawText(hDC, TEXT("Deactivated!"), -1, &rect, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
   ReleaseDC(hWindow, hDC);
}


void GamePaint(HDC hDC)
{ }


void GameCycle()
{
   HWND hWindow = _pGame->GetWindow();
   HDC  hDC     = GetDC(hWindow);

   DrawIcon(hDC, rtk::rand(0, _pGame->GetWidth()), rtk::rand(0, _pGame->GetHeight()),
            (HICON) GetClassLongPtr(hWindow, GCLP_HICON));

   ReleaseDC(hWindow, hDC);
}