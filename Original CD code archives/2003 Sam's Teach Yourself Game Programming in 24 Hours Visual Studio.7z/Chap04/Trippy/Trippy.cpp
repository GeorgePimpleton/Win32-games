//-----------------------------------------------------------------
// Trippy Application
// C++ Source - Trippy.cpp
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// include files
//-----------------------------------------------------------------
#include "Trippy.hpp"

//-----------------------------------------------------------------
// game engine functions
//-----------------------------------------------------------------
BOOL GameInitialize(HINSTANCE hInstance)
{
   // create the game engine
   _pGame = new GameEngine(hInstance, TEXT("Trippy"), TEXT("Trippy"),
                           IDI_TRIPPY, IDI_TRIPPY_SM);

   if (_pGame == NULL)
   {
      return FALSE;
   }

   // set the frame rate
   _pGame->SetFrameRate(15);

   return TRUE;
}


void GameStart(HWND hWindow)
{
   // seed the random number generator
   rtk::srand();

   // set the position and size of the initial rectangle
   _rcRectangle.left   = _pGame->GetWidth() * 2 / 5;
   _rcRectangle.top    = _pGame->GetHeight() * 2 / 5;
   _rcRectangle.right  = _rcRectangle.left + _pGame->GetWidth() / 5;
   _rcRectangle.bottom = _rcRectangle.top + _pGame->GetHeight() / 5;
}


void GameEnd()
{
   // cleanup the game engine
   delete _pGame;
}


void GameActivate(HWND hWindow)
{ }


void GameDeactivate(HWND hWindow)
{ }


void GamePaint(HDC hDC)
{
   const int iGridLines = 50;

   for (int i = 1; i <= iGridLines; i++)
   {
      // draw a horizontal grid line
      MoveToEx(hDC, _pGame->GetWidth() * i / iGridLines, 0, NULL);
      LineTo(hDC, _pGame->GetWidth() * i / iGridLines, _pGame->GetHeight());

      // draw a vertical grid line
      MoveToEx(hDC, 0, _pGame->GetHeight() * i / iGridLines, NULL);
      LineTo(hDC, _pGame->GetWidth(), _pGame->GetHeight() * i / iGridLines);
   }
}


void GameCycle()
{
   // randomly alter the position and size of the rectangle
   int iInflation = rtk::rand(-10, 10);

   InflateRect(&_rcRectangle, iInflation, iInflation);
   OffsetRect(&_rcRectangle, rtk::rand(-9, 9), rtk::rand(-9, 9));

   // draw the new rectangle in a random color
   HBRUSH hBrush  = CreateSolidBrush(RGB(rtk::rand(0, 255), rtk::rand(0, 255), rtk::rand(0, 255)));
   HWND   hWindow = _pGame->GetWindow();
   HDC    hDC     = GetDC(hWindow);

   FillRect(hDC, &_rcRectangle, hBrush);
   ReleaseDC(hWindow, hDC);
   DeleteObject(hBrush);
}
