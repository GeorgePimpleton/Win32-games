/* A simple toolkit to help beginners using <random> library easier */

#ifndef __RANDOM_TOOLKIT_HPP__
#define __RANDOM_TOOLKIT_HPP__

#include <random>
#include <chrono>

namespace rtk
{
   inline std::default_random_engine& urng()
   {
      static std::default_random_engine URNG { };
      return URNG;
   }

   inline void srand()
   {
      std::random_device rd;
      unsigned           seed;

      if (0 != rd.entropy()) // check if the implementation provides a usable random_device
      {
         seed = rd();  // it does, it does!!!
      }
      else
      {
         // no random_device available, seed using the system clock
         seed = static_cast<unsigned> (std::chrono::system_clock::now().time_since_epoch().count());
      }

      urng().seed(seed);
   }

   inline int rand(int from, int to)
   {
      static std::uniform_int_distribution<> dist { };
      using pt = decltype(dist)::param_type;
      return dist(urng(), pt { from, to });
   }

   inline double rand(double from, double to)
   {
      static std::uniform_real_distribution<> dist { };
      using pt = decltype(dist)::param_type;
      return dist(urng(), pt { from, to });
   }
}

#endif
