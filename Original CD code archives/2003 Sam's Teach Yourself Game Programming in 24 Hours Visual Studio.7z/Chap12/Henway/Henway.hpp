//-----------------------------------------------------------------
// Henway Application
// C++ Header - Henway.hpp
//-----------------------------------------------------------------

#pragma once

//-----------------------------------------------------------------
// include files
//-----------------------------------------------------------------
#include <windows.h>
#include "random_toolkit.hpp"
#include "resource.h"
#include "GameEngine.hpp"
#include "Bitmap.hpp"
#include "Sprite.hpp"

//-----------------------------------------------------------------
// global variables
//-----------------------------------------------------------------
GameEngine* _pGame;
HDC         _hOffscreenDC;
HBITMAP     _hOffscreenBitmap;
Bitmap*     _pHighwayBitmap;
Bitmap*     _pChickenBitmap;
Bitmap*     _pCarBitmaps[4];
Bitmap*     _pChickenHeadBitmap;
Sprite*     _pChickenSprite;
int         _iInputDelay;
int         _iNumLives;
int         _iScore;
BOOL        _bGameOver;

//-----------------------------------------------------------------
// function declarations
//-----------------------------------------------------------------
void MoveChicken(int iXDistance, int iYDistance);
