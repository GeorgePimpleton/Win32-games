//-----------------------------------------------------------------
// Alien Sprite Object
// C++ Source - AlienSprite.cpp
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// include files
//-----------------------------------------------------------------
#include "AlienSprite.hpp"

//-----------------------------------------------------------------
// External Global Variables
//-----------------------------------------------------------------
extern Bitmap* _pBlobboBitmap;
extern Bitmap* _pBMissileBitmap;
extern Bitmap* _pJellyBitmap;
extern Bitmap* _pJMissileBitmap;
extern Bitmap* _pTimmyBitmap;
extern Bitmap* _pTMissileBitmap;
extern int     _iDifficulty;


//-----------------------------------------------------------------
// AlienSprite constructor(s)/destructor
//-----------------------------------------------------------------
AlienSprite::AlienSprite(Bitmap* pBitmap, RECT& rcBounds, BOUNDSACTION baBoundsAction)
   : Sprite(pBitmap, rcBounds, baBoundsAction)
{ }


AlienSprite::~AlienSprite()
{ }


//-----------------------------------------------------------------
// AlienSprite general methods
//-----------------------------------------------------------------
SPRITEACTION AlienSprite::Update()
{
   // call the base sprite update() method
   SPRITEACTION saSpriteAction;

   saSpriteAction = Sprite::Update();

   // see if the alien should fire a missile
   if (rtk::rand(0, _iDifficulty / 2) == 0)
   {
      saSpriteAction |= SA_ADDSPRITE;
   }

   return saSpriteAction;
}


Sprite* AlienSprite::AddSprite()
{
   // create a new missile sprite
   RECT    rcBounds = { 0, 0, 640, 410 };
   RECT    rcPos    = GetPosition();
   Sprite* pSprite  = NULL;

   if (GetBitmap() == _pBlobboBitmap)
   {
      // Blobbo missile
      pSprite = new Sprite(_pBMissileBitmap, rcBounds, BA_DIE);
      pSprite->SetVelocity(0, 7);
   }
   else if (GetBitmap() == _pJellyBitmap)
   {
      // Jelly missile
      pSprite = new Sprite(_pJMissileBitmap, rcBounds, BA_DIE);
      pSprite->SetVelocity(0, 5);
   }
   else
   {
      // Timmy missile
      pSprite = new Sprite(_pTMissileBitmap, rcBounds, BA_DIE);
      pSprite->SetVelocity(0, 3);
   }

   // set the missile sprite's position and return it
   pSprite->SetPosition(rcPos.left + (GetWidth() / 2), rcPos.bottom);
   return pSprite;
}