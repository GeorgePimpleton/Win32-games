//-----------------------------------------------------------------
// Alien Sprite Object
// C++ Header - AlienSprite.hpp
//-----------------------------------------------------------------

#pragma once

//-----------------------------------------------------------------
// include files
//-----------------------------------------------------------------
#include <windows.h>
#include "random_toolkit.hpp"
#include "Sprite.hpp"

//-----------------------------------------------------------------
// AlienSprite class
//-----------------------------------------------------------------
class AlienSprite : public Sprite
{
public:
   // constructor(s)/destructor
            AlienSprite(Bitmap* pBitmap, RECT& rcBounds, BOUNDSACTION baBoundsAction = BA_STOP);
   virtual ~AlienSprite();

   // general methods
   virtual SPRITEACTION Update();
   virtual Sprite*      AddSprite();
};
