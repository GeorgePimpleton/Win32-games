//-----------------------------------------------------------------
// Brainiac 2 Application
// C++ Header - Brainiac 2.hpp
//-----------------------------------------------------------------

#pragma once

//-----------------------------------------------------------------
// include files
//-----------------------------------------------------------------
#include <windows.h>
#include "random_toolkit.hpp"
#include "resource.h"
#include "GameEngine.hpp"
#include "Bitmap.hpp"
#include "Sprite.hpp"

//-----------------------------------------------------------------
// global variables
//-----------------------------------------------------------------
GameEngine* _pGame;
Bitmap*     _pTiles[9];
BOOL        _bTileStates[4][4];
int         _iTiles[4][4];
POINT       _ptTile1;
POINT       _ptTile2;
int         _iMatches;
int         _iTries;
