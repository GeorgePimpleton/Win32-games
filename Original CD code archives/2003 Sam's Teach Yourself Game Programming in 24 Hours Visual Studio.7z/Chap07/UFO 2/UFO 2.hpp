//-----------------------------------------------------------------
// UFO 2 Application
// C++ Header - UFO 2.hpp
//-----------------------------------------------------------------

#pragma once

//-----------------------------------------------------------------
// include files
//-----------------------------------------------------------------
#include <windows.h>
#include "random_toolkit.hpp"
#include "resource.h"
#include "GameEngine.hpp"
#include "Bitmap.hpp"

//-----------------------------------------------------------------
// global variables
//-----------------------------------------------------------------
GameEngine* _pGame;
const int   _iMAXSPEED = 8;
Bitmap*     _pBackground;
Bitmap*     _pSaucer[2];
int         _iSaucerX, _iSaucerY;
int         _iSpeedX, _iSpeedY;
BOOL        _bSaucerFlame;