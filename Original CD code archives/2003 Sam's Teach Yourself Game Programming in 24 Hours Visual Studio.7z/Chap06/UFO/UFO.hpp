//-----------------------------------------------------------------
// UFO Application
// C++ Header - UFO.hpp
//-----------------------------------------------------------------

#pragma once

//-----------------------------------------------------------------
// include files
//-----------------------------------------------------------------
#include <windows.h>
#include "resource.h"
#include "GameEngine.hpp"
#include "Bitmap.hpp"

//-----------------------------------------------------------------
// global variables
//-----------------------------------------------------------------
GameEngine* _pGame;
const int   _iMAXSPEED = 8;
Bitmap*     _pBackground;
Bitmap*     _pSaucer;
int         _iSaucerX, _iSaucerY;
int         _iSpeedX, _iSpeedY;
