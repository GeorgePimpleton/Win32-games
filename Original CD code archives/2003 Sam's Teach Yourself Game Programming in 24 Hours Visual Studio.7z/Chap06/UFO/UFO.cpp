//-----------------------------------------------------------------
// UFO Application
// C++ Source - UFO.cpp
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// include files
//-----------------------------------------------------------------
#include "UFO.hpp"

//-----------------------------------------------------------------
// game engine functions
//-----------------------------------------------------------------
BOOL GameInitialize(HINSTANCE hInstance)
{
   // create the game engine
   _pGame = new GameEngine(hInstance, TEXT("UFO"), TEXT("UFO"),
                           IDI_UFO, IDI_UFO_SM, 500, 400);

   if (_pGame == NULL)
   {
      return FALSE;
   }

   // set the frame rate
   _pGame->SetFrameRate(30);

   return TRUE;
}


void GameStart(HWND hWindow)
{
   // create and load the background and saucer bitmaps
   HINSTANCE hInstance = GetModuleHandle(NULL);
   ;
   _pBackground = new Bitmap(IDB_BACKGROUND, hInstance);
   _pSaucer     = new Bitmap(IDB_SAUCER, hInstance);

   // set the initial saucer position and speed
   _iSaucerX = 250 - (_pSaucer->GetWidth() / 2);
   _iSaucerY = 200 - (_pSaucer->GetHeight() / 2);
   _iSpeedX  = 0;
   _iSpeedY  = 0;
}


void GameEnd()
{
   // cleanup the background and saucer bitmaps
   delete _pBackground;
   delete _pSaucer;

   // cleanup the game engine
   delete _pGame;
}


void GameActivate(HWND hWindow)
{ }


void GameDeactivate(HWND hWindow)
{ }


void GamePaint(HDC hDC)
{
   // Draw the background and saucer bitmaps
   _pBackground->Draw(hDC, 0, 0);
   _pSaucer->Draw(hDC, _iSaucerX, _iSaucerY, TRUE);
}


void GameCycle()
{
   // Update the saucer position
   _iSaucerX = min(500 - _pSaucer->GetWidth(), max(0, _iSaucerX + _iSpeedX));
   _iSaucerY = min(320, max(0, _iSaucerY + _iSpeedY));

   // force a repaint to redraw the saucer
   InvalidateRect(_pGame->GetWindow(), NULL, FALSE);
}


void HandleKeys()
{
   // change the speed of the saucer in response to arrow key presses
   if (GetAsyncKeyState(VK_LEFT) < 0)
   {
      _iSpeedX = max(-_iMAXSPEED, --_iSpeedX);
   }
   else if (GetAsyncKeyState(VK_RIGHT) < 0)
   {
      _iSpeedX = min(_iMAXSPEED, ++_iSpeedX);
   }

   if (GetAsyncKeyState(VK_UP) < 0)
   {
      _iSpeedY = max(-_iMAXSPEED, --_iSpeedY);
   }
   else if (GetAsyncKeyState(VK_DOWN) < 0)
   {
      _iSpeedY = min(_iMAXSPEED, ++_iSpeedY);
   }
}


void MouseButtonDown(int x, int y, BOOL bLeft)
{
   if (bLeft)
   {
      // set the saucer position to the mouse position
      _iSaucerX = x - (_pSaucer->GetWidth() / 2);
      _iSaucerY = y - (_pSaucer->GetHeight() / 2);
   }
   else
   {
      // Stop the saucer
      _iSpeedX = 0;
      _iSpeedY = 0;
   }
}


void MouseButtonUp(int x, int y, BOOL bLeft)
{ }


void MouseMove(int x, int y)
{ }
