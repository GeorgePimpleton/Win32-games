//-----------------------------------------------------------------
// Fore Application
// C++ Header - Fore.hpp
//-----------------------------------------------------------------

#pragma once

//-----------------------------------------------------------------
// include files
//-----------------------------------------------------------------
#include <windows.h>
#include "random_toolkit.hpp"
#include "resource.h"
#include "GameEngine.hpp"
#include "Bitmap.hpp"
#include "Sprite.hpp"

//-----------------------------------------------------------------
// global variables
//-----------------------------------------------------------------
GameEngine* _pGame;
Bitmap*     _pForestBitmap;
Bitmap*     _pGolfBallBitmap;
Sprite*     _pGolfBallSprite[3];
BOOL        _bDragging;
int         _iDragBall;
