//-----------------------------------------------------------------
// Fore Application
// C++ Source - Fore.cpp
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// include files
//-----------------------------------------------------------------
#include "Fore.hpp"

//-----------------------------------------------------------------
// game engine functions
//-----------------------------------------------------------------
BOOL GameInitialize(HINSTANCE hInstance)
{
   // create the game engine
   _pGame = new GameEngine(hInstance, TEXT("Fore"), TEXT("Fore"),
                           IDI_FORE, IDI_FORE_SM, 600, 400);

   if (_pGame == NULL)
   {
      return FALSE;
   }

   // set the frame rate
   _pGame->SetFrameRate(30);

   return TRUE;
}


void GameStart(HWND hWindow)
{
   // seed the random number generator
   rtk::srand();

   // create and load the bitmaps
   HINSTANCE hInstance = GetModuleHandle(NULL);

   _pForestBitmap   = new Bitmap(IDB_FOREST, hInstance);
   _pGolfBallBitmap = new Bitmap(IDB_GOLFBALL, hInstance);

   // create the golf ball sprites
   RECT rcBounds = { 0, 0, 600, 400 };

   _pGolfBallSprite[0] = new Sprite(_pGolfBallBitmap, rcBounds);
   _pGolfBallSprite[1] = new Sprite(_pGolfBallBitmap, rcBounds, BA_WRAP);
   _pGolfBallSprite[2] = new Sprite(_pGolfBallBitmap, rcBounds, BA_BOUNCE);

   _pGolfBallSprite[0]->SetVelocity(2, 1);
   _pGolfBallSprite[1]->SetVelocity(3, -2);
   _pGolfBallSprite[2]->SetVelocity(7, 4);

   // set the initial drag info
   _bDragging = FALSE;
   _iDragBall = -1;
}


void GameEnd()
{
   // cleanup the bitmaps
   delete _pForestBitmap;
   delete _pGolfBallBitmap;

   // cleanup the sprites
   for (int i = 0; i < 3; i++)
   {
      delete _pGolfBallSprite[i];
   }

   // cleanup the game engine
   delete _pGame;
}


void GameActivate(HWND hWindow)
{ }


void GameDeactivate(HWND hWindow)
{ }


void GamePaint(HDC hDC)
{
   // draw the background forest
   _pForestBitmap->Draw(hDC, 0, 0);

   // draw the golf ball sprites
   for (int i = 0; i < 3; i++)
   {
      _pGolfBallSprite[i]->Draw(hDC);
   }
}


void GameCycle()
{
   // update the golf ball sprites
   for (int i = 0; i < 3; i++)
   {
      _pGolfBallSprite[i]->Update();
   }

   // force a repaint to redraw the golf balls
   InvalidateRect(_pGame->GetWindow(), NULL, FALSE);
}


void HandleKeys()
{ }


void MouseButtonDown(int x, int y, BOOL bLeft)
{
   // see if a ball was clicked with the left mouse button
   if (bLeft && !_bDragging)
   {
      for (int i = 0; i < 3; i++)
      {
         if (_pGolfBallSprite[i]->IsPointInside(x, y))
         {
            // capture the mouse
            SetCapture(_pGame->GetWindow());

            // set the drag state and the drag ball
            _bDragging = TRUE;
            _iDragBall = i;

            // simulate a mouse move to get started
            MouseMove(x, y);

            // don't check for more balls
            break;
         }
      }
   }
}


void MouseButtonUp(int x, int y, BOOL bLeft)
{
   // release the mouse
   ReleaseCapture();

   // stop dragging
   _bDragging = FALSE;
}


void MouseMove(int x, int y)
{
   if (_bDragging)
   {
      // move the sprite to the mouse cursor position
      _pGolfBallSprite[_iDragBall]->SetPosition(
         x - (_pGolfBallBitmap->GetWidth() / 2),
         y - (_pGolfBallBitmap->GetHeight() / 2));

      // force a repaint to redraw the golf balls
      InvalidateRect(_pGame->GetWindow(), NULL, FALSE);
   }
}


void HandleJoystick(JOYSTATE jsJoystickState)
{ }