//-----------------------------------------------------------------
// Roids 2 Application
// C++ Header - Roids 2.hpp
//-----------------------------------------------------------------

#pragma once

//-----------------------------------------------------------------
// include files
//-----------------------------------------------------------------
#include <windows.h>
#include "resource.h"
#include "random_toolkit.hpp"
#include "GameEngine.hpp"
#include "Bitmap.hpp"
#include "Sprite.hpp"
#include "Background.hpp"

//-----------------------------------------------------------------
// global variables
//-----------------------------------------------------------------
GameEngine*       _pGame;
HDC               _hOffscreenDC;
HBITMAP           _hOffscreenBitmap;
Bitmap*           _pAsteroidBitmap;
Bitmap*           _pSaucerBitmap;
StarryBackground* _pBackground;
Sprite*           _pAsteroids[3];
Sprite*           _pSaucer;

//-----------------------------------------------------------------
// function declarations
//-----------------------------------------------------------------
void UpdateSaucer();
