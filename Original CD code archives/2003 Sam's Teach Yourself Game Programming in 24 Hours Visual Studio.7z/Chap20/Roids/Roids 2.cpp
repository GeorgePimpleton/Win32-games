//-----------------------------------------------------------------
// Roids 2 Application
// C++ Source - Roids 2.cpp
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// include files
//-----------------------------------------------------------------
#include "Roids 2.hpp"

//-----------------------------------------------------------------
// game engine functions
//-----------------------------------------------------------------
BOOL GameInitialize(HINSTANCE hInstance)
{
   // create the game engine
   _pGame = new GameEngine(hInstance, TEXT("Roids 2"), TEXT("Roids 2"),
                           IDI_ROIDS, IDI_ROIDS_SM, 500, 400);

   if (_pGame == NULL)
   {
      return FALSE;
   }

   // set the frame rate
   _pGame->SetFrameRate(30);

   return TRUE;
}


void GameStart(HWND hWindow)
{
   // seed the random number generator
   rtk::srand();

   // create the offscreen device context and bitmap
   _hOffscreenDC = CreateCompatibleDC(GetDC(hWindow));
   _hOffscreenBitmap = CreateCompatibleBitmap(GetDC(hWindow), _pGame->GetWidth(), _pGame->GetHeight());

   SelectObject(_hOffscreenDC, _hOffscreenBitmap);

   // create and load the asteroid and saucer bitmaps
   _pAsteroidBitmap = new Bitmap(IDB_ASTEROID, GetModuleHandle(NULL));
   _pSaucerBitmap   = new Bitmap(IDB_SAUCER, GetModuleHandle(NULL));

   // create the starry background
   _pBackground = new StarryBackground(500, 400);

   // create the asteroid sprites
   RECT    rcBounds = { 0, 0, 500, 400 };

   _pAsteroids[0] = new Sprite(_pAsteroidBitmap, rcBounds, BA_WRAP);
   _pAsteroids[0]->SetNumFrames(14);
   _pAsteroids[0]->SetFrameDelay(1);
   _pAsteroids[0]->SetPosition(250, 200);
   _pAsteroids[0]->SetVelocity(-3, 1);
   _pGame->AddSprite(_pAsteroids[0]);

   _pAsteroids[1] = new Sprite(_pAsteroidBitmap, rcBounds, BA_WRAP);
   _pAsteroids[1]->SetNumFrames(14);
   _pAsteroids[1]->SetFrameDelay(2);
   _pAsteroids[1]->SetPosition(250, 200);
   _pAsteroids[1]->SetVelocity(3, -2);
   _pGame->AddSprite(_pAsteroids[1]);

   _pAsteroids[2] = new Sprite(_pAsteroidBitmap, rcBounds, BA_WRAP);
   _pAsteroids[2]->SetNumFrames(14);
   _pAsteroids[2]->SetFrameDelay(3);
   _pAsteroids[2]->SetPosition(250, 200);
   _pAsteroids[2]->SetVelocity(-2, -4);
   _pGame->AddSprite(_pAsteroids[2]);

   // create the saucer sprite
   _pSaucer = new Sprite(_pSaucerBitmap, rcBounds, BA_WRAP);
   _pSaucer->SetPosition(0, 0);
   _pSaucer->SetVelocity(3, 1);
   _pGame->AddSprite(_pSaucer);
}


void GameEnd()
{
   // cleanup the offscreen device context and bitmap
   DeleteObject(_hOffscreenBitmap);
   DeleteDC(_hOffscreenDC);

   // cleanup the asteroid and saucer bitmaps
   delete _pAsteroidBitmap;
   delete _pSaucerBitmap;

   // cleanup the background
   delete _pBackground;

   // cleanup the sprites
   _pGame->CleanupSprites();

   // cleanup the game engine
   delete _pGame;
}


void GameActivate(HWND hWindow)
{ }


void GameDeactivate(HWND hWindow)
{ }


void GamePaint(HDC hDC)
{
   // draw the background
   _pBackground->Draw(hDC);

   // draw the sprites
   _pGame->DrawSprites(hDC);
}


void GameCycle()
{
   // update the background
   _pBackground->Update();

   // update the sprites
   _pGame->UpdateSprites();

   // update the saucer to help it dodge the asteroids
   UpdateSaucer();

   // obtain a device context for repainting the game
   HWND hWindow = _pGame->GetWindow();
   HDC  hDC     = GetDC(hWindow);

   // paint the game to the offscreen device context
   GamePaint(_hOffscreenDC);

   // blit the offscreen bitmap to the game screen
   BitBlt(hDC, 0, 0, _pGame->GetWidth(), _pGame->GetHeight(), _hOffscreenDC, 0, 0, SRCCOPY);

   // cleanup
   ReleaseDC(hWindow, hDC);
}


void HandleKeys()
{ }


void MouseButtonDown(int x, int y, BOOL bLeft)
{ }


void MouseButtonUp(int x, int y, BOOL bLeft)
{ }


void MouseMove(int x, int y)
{ }


void HandleJoystick(JOYSTATE jsJoystickState)
{ }


BOOL SpriteCollision(Sprite* pSpriteHitter, Sprite* pSpriteHittee)
{
   return FALSE;
}


void SpriteDying(Sprite* pSprite)
{ }

//-----------------------------------------------------------------
// functions
//-----------------------------------------------------------------
void UpdateSaucer()
{
   // obtain the saucer's position
   RECT rcSaucer, rcRoid;

   rcSaucer = _pSaucer->GetPosition();

   // find out which asteroid is closest to the saucer
   int iXCollision = 500, iYCollision = 400, iXYCollision = 900;

   for (int i = 0; i < 3; i++)
   {
      // get the asteroid position
      rcRoid = _pAsteroids[i]->GetPosition();

      // Calculate the minimum XY collision distance
      int iXCollisionDist = (rcSaucer.left + (rcSaucer.right - rcSaucer.left) / 2) -
                             (rcRoid.left + (rcRoid.right - rcRoid.left) / 2);
      int iYCollisionDist = (rcSaucer.top + (rcSaucer.bottom - rcSaucer.top) / 2) -
                             (rcRoid.top + (rcRoid.bottom - rcRoid.top) / 2);

      if ((abs(iXCollisionDist) < abs(iXCollision)) || (abs(iYCollisionDist) < abs(iYCollision)))
      {
         if ((abs(iXCollisionDist) + abs(iYCollisionDist)) < iXYCollision)
         {
            iXYCollision = abs(iXCollision) + abs(iYCollision);
            iXCollision  = iXCollisionDist;
            iYCollision  = iYCollisionDist;
         }
      }
   }

   // move to dodge the asteroids, if necessary
   POINT ptVelocity;

   ptVelocity = _pSaucer->GetVelocity();

   if (abs(iXCollision) < 60)
   {
      // adjust the x velocity
      if (iXCollision < 0)
      {
         ptVelocity.x = max(ptVelocity.x - 1, -8);
      }
      else
      {
         ptVelocity.x = min(ptVelocity.x + 1, 8);
      }
   }

   if (abs(iYCollision) < 60)
   {
      // adjust the y velocity
      if (iYCollision < 0)
      {
         ptVelocity.y = max(ptVelocity.y - 1, -8);
      }
      else
      {
         ptVelocity.y = min(ptVelocity.y + 1, 8);
      }
   }

   // update the saucer to the new position
   _pSaucer->SetVelocity(ptVelocity);
}