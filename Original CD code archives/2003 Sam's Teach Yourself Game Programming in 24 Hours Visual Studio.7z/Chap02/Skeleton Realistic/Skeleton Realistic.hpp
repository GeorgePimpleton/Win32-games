//-----------------------------------------------------------------
// Skeleton Realistic Application
// C++ Header - Skeleton Realistic.hpp
//-----------------------------------------------------------------

#pragma once

//-----------------------------------------------------------------
// include files
//-----------------------------------------------------------------
#include <windows.h>
#include "resource 2.h"

//-----------------------------------------------------------------
// Windows function declarations
//-----------------------------------------------------------------
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK    DlgProc(HWND, UINT, WPARAM, LPARAM);
