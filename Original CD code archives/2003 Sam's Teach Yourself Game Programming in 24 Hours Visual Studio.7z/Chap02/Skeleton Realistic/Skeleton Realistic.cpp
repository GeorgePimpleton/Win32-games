//-----------------------------------------------------------------
// Skeleton Realistic Application
// C++ Source - Skeleton Realistic.cpp
//-----------------------------------------------------------------

#include "Skeleton Realistic.hpp"

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR szCmdLine, int iCmdShow)
{
   static TCHAR szAppName[]  = TEXT("Skeleton 2");

   WNDCLASSEX wc;

   wc.cbSize        = sizeof(WNDCLASSEX);
   wc.style         = CS_HREDRAW | CS_VREDRAW;
   wc.lpfnWndProc   = WndProc;
   wc.cbClsExtra    = 0;
   wc.cbWndExtra    = 0;
   wc.hInstance     = hInstance;
   wc.hIcon         = (HICON)   LoadImage(hInstance, MAKEINTRESOURCE(IDI_ICON), IMAGE_ICON, 0, 0, LR_DEFAULTCOLOR);
   wc.hIconSm       = (HICON)   LoadImage(hInstance, MAKEINTRESOURCE(IDI_ICON_SM), IMAGE_ICON, 0, 0, LR_DEFAULTCOLOR);
   wc.hCursor       = (HCURSOR) LoadImage(NULL, IDC_ARROW, IMAGE_CURSOR, 0, 0, LR_SHARED);
   wc.hbrBackground = (HBRUSH)  (COLOR_WINDOW + 1);
   wc.lpszMenuName  = MAKEINTRESOURCE(IDR_MENU);
   wc.lpszClassName = szAppName;

   if (0 == RegisterClassEx(&wc))
   {
      MessageBox(NULL, TEXT("Can't Register the Window Class!"), szAppName, MB_OK | MB_ICONERROR);
      return E_FAIL;
   }

   static TCHAR szAppTitle[] = TEXT("A Windows Game Programming Primer");

   HWND hwnd = CreateWindow(szAppName, szAppTitle,
                            WS_OVERLAPPEDWINDOW,
                            CW_USEDEFAULT, CW_USEDEFAULT,
                            CW_USEDEFAULT, CW_USEDEFAULT,
                            NULL, NULL, hInstance, NULL);

   if (NULL == hwnd)
   {
      MessageBox(NULL, TEXT("Unable to Create the Main Window!"), szAppName, MB_OK | MB_ICONERROR);
      return E_FAIL;
   }

   ShowWindow(hwnd, iCmdShow);
   UpdateWindow(hwnd);

   // load the accelerators
   HACCEL hAccel = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDR_ACCEL));

   // check accelerators are loaded
   // the app can still run without accelerators
   if (NULL == hAccel)
   {
      MessageBox(NULL, TEXT("Unable to Load the Accelerators!"), szAppName, MB_OK | MB_ICONERROR);
   }

   static BOOL bRet;
   static MSG  msg;

   // enter the main message loop
   while ((bRet = GetMessage(&msg, NULL, 0, 0)) != 0) // 0 = WM_QUIT
   {
      // check for error
      if (-1 == bRet)
      {
         // handle the error and possibly exit

         // for this app simply report error and exit
         MessageBox(NULL, TEXT("Unable to Continue!"), szAppName, MB_OK | MB_ICONERROR);
         return E_FAIL;
      }
      else
      {
         // check for accelerator keystrokes
         if (0 == TranslateAccelerator(hwnd, hAccel, &msg))
         {
            // no accelerator used so process the message
            TranslateMessage(&msg);
            DispatchMessage(&msg);
         }
      }
   }

   // the app is done, exit normally, return control to Windows
   return (int) msg.wParam;
}


LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
   switch (message)
   {
   // process menu items
   case WM_COMMAND:
      switch (LOWORD(wParam))
      {
      case IDM_GAME_EXIT:
         // the exit menu item was selected, tell Windows to exit the app
         PostQuitMessage(0);

         return S_OK;

      case IDM_HELP_ABOUT:
         // the About... menu item was selected, display the app's pre-defined dialog box
         DialogBox((HINSTANCE) GetWindowLongPtr(hwnd, GWLP_HINSTANCE), MAKEINTRESOURCE(IDD_ABOUT), hwnd, (DLGPROC) DlgProc);

         return S_OK;
      }
      break;

   case WM_CREATE:
      // set the custom cursor as the class cursor
      SetClassLongPtr(hwnd, GCLP_HCURSOR,
                      (LONG64) LoadImage(GetModuleHandle(NULL), MAKEINTRESOURCE(IDC_CURSOR), IMAGE_CURSOR, 0, 0, LR_DEFAULTCOLOR));

      return S_OK;

   case WM_PAINT:
      HDC         hdc;
      PAINTSTRUCT ps;

      hdc = BeginPaint(hwnd, &ps);

      RECT rect;

      GetClientRect(hwnd, &rect);

      DrawText(hdc, TEXT("This is a realistic skeletal Windows� application!"), -1, &rect, DT_SINGLELINE | DT_CENTER | DT_VCENTER);

      EndPaint(hwnd, &ps);

      return S_OK;

   case WM_DESTROY:
      PostQuitMessage(0);

      return S_OK;
   }

   return DefWindowProc(hwnd, message, wParam, lParam);
}


// handle dialog box messages
BOOL CALLBACK DlgProc(HWND hDialog, UINT message, WPARAM wParam, LPARAM lParam)
{
   // process dialog box messages
   switch (message)
   {
   // choose the message(s) to process
   case WM_COMMAND:
      switch (LOWORD(wParam))
      {
      case IDOK:
         // the OK button was pushed, exit the dialog box
         EndDialog(hDialog, 0);

         return TRUE;
      }
   }

   // no dialog box message processed
   return FALSE;
}