//-----------------------------------------------------------------
// Slideshow Application
// C++ Header - Slideshow.h
//-----------------------------------------------------------------

#pragma once

//-----------------------------------------------------------------
// Include Files
//-----------------------------------------------------------------
#include <windows.h>
#include "Resource.h"
#include "GameEngine.h"
#include "Bitmap.h"

//-----------------------------------------------------------------
// Global Variables
//-----------------------------------------------------------------
HINSTANCE   _hInstance;
GameEngine* _pGame;
const int   _iNUMSLIDES = 7;
Bitmap*     _pSlides[_iNUMSLIDES];
int         _iCurSlide;
