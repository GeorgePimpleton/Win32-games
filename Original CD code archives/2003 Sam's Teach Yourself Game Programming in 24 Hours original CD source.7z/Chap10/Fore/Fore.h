//-----------------------------------------------------------------
// Fore Application
// C++ Header - Fore.h
//-----------------------------------------------------------------

#pragma once

//-----------------------------------------------------------------
// Include Files
//-----------------------------------------------------------------
#include <windows.h>
#include "Resource.h"
#include "GameEngine.h"
#include "Bitmap.h"
#include "Sprite.h"

//-----------------------------------------------------------------
// Global Variables
//-----------------------------------------------------------------
HINSTANCE   _hInstance;
GameEngine* _pGame;
Bitmap*     _pForestBitmap;
Bitmap*     _pGolfBallBitmap;
Sprite*     _pGolfBallSprite[3];
BOOL        _bDragging;
int         _iDragBall;
