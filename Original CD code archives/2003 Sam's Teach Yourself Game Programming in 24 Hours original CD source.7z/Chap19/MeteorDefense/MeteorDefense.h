//-----------------------------------------------------------------
// Meteor Defense Application
// C++ Header - MeteorDefense.h
//-----------------------------------------------------------------

#pragma once

//-----------------------------------------------------------------
// Include Files
//-----------------------------------------------------------------
#include <windows.h>
#include "Resource.h"
#include "GameEngine.h"
#include "Bitmap.h"
#include "Sprite.h"
#include "Background.h"

//-----------------------------------------------------------------
// Global Variables
//-----------------------------------------------------------------
HINSTANCE         _hInstance;
GameEngine*       _pGame;
HDC               _hOffscreenDC;
HBITMAP           _hOffscreenBitmap;
Bitmap*           _pGroundBitmap;
Bitmap*           _pTargetBitmap;
Bitmap*           _pCityBitmap;
Bitmap*           _pMeteorBitmap;
Bitmap*           _pMissileBitmap;
Bitmap*           _pExplosionBitmap;
Bitmap*           _pGameOverBitmap;
StarryBackground* _pBackground;
Sprite*           _pTargetSprite;
int               _iNumCities, _iScore, _iDifficulty;
BOOL              _bGameOver;

//-----------------------------------------------------------------
// Function Declarations
//-----------------------------------------------------------------
void NewGame();
void AddMeteor();
